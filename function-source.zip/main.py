import urllib3

def function(request):
    #Parse URL Parameters
    request_args = request.args

    http_method = request_args["http_method"]
    url = request_args["url"]
    port = request_args["port"]
    token = request_args["token"]

    #Build Full URL out of Parameters
    full_url = http_method+'://'+url+':'+port+'/services/collector/raw'
    
    #Get Body
    webhook_body = request.data

    #Create URLLib3 Pool Manager
    http = urllib3.PoolManager()
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    #Post Event
    r = http.request('POST', full_url, body=webhook_body, headers={'Content-Type': 'application/json', 'Authorization':'Splunk '+token})

    return {
        'statusCode': 200,
        'body':'Success'
    }